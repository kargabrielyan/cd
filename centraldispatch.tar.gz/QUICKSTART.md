# Быстрый старт

## 1. Установка зависимостей

Зависимости уже установлены. Если нужно переустановить:
```bash
npm install
```

## 2. Настройка Email

Создайте файл `.env.local` в корне проекта:

```env
# Email настройки (Gmail)
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USER=ваш-email@gmail.com
EMAIL_PASS=ваш-app-password
EMAIL_TO=адрес-для-уведомлений@example.com

# Секрет для сессий (любая случайная строка)
SESSION_SECRET=любая-случайная-строка-секрет

# Basic Auth (опционально, для защиты тестовой среды)
# ENABLE_BASIC_AUTH=true
# BASIC_AUTH_USER=tester
# BASIC_AUTH_PASS=test123
```

### Как получить Gmail App Password:

1. Включите двухфакторную аутентификацию в Google аккаунте
2. Перейдите: https://myaccount.google.com/security
3. Найдите "2-Step Verification" → "App passwords"
4. Создайте пароль для "Mail"
5. Используйте этот пароль в `EMAIL_PASS` (не ваш обычный пароль!)

## 3. Запуск проекта

```bash
npm run dev
```

Откройте в браузере: http://localhost:3000

## 4. Тестирование потока

1. Откройте http://localhost:3000
2. Введите любой Username и Password
3. Нажмите "SIGN IN"
4. Проверьте ваш Email - должно прийти письмо с логином и паролем
5. Введите любой 6-значный код (например: 123456)
6. Нажмите "ПОДТВЕРДИТЬ"
7. Проверьте ваш Email - должно прийти письмо с кодом
8. Вы увидите страницу 404

## Важно

- Убедитесь, что `.env.local` заполнен правильно
- Для продакшена используйте более надежный Email сервис (SendGrid, Mailgun)
- В консоли браузера и терминале вы увидите логи всех операций


