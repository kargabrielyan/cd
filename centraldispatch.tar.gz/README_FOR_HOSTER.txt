=============================================================================
STAGING / TEST ENVIRONMENT
=============================================================================

This is a TEST/STAGING environment for demonstration purposes only.

DO NOT ENTER REAL DATA OR PERSONAL INFORMATION

Contact Developer: [ваш-email@example.com]
Purpose: Testing and demonstration

This application is for testing purposes and should not be used in production.

=============================================================================

