import SignInForm from "@/components/SignInForm/SignInForm";

export default function SignInPage() {
  return <SignInForm />;
}


